package org.iesalandalus.programacion.introjava.secuenciales;

public class AsignarValor {

    public static void main(String[] args) {
        int numero;
        numero = 10;
        System.out.println("El valor del número  es: " + numero);
    }

}